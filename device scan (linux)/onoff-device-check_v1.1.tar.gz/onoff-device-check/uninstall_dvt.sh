#!/bin/bash

### Check root permission
if [ "$EUID" -ne 0 ]; then
    echo "Please run with sudo"
    exit
fi

SCRIPT_WIN="dvt_win.sh"
SCRIPT="dvt_reboot.sh"
DESKTOP="dvt.desktop"

sudo rm /home/${SUDO_USER}/.config/autostart/$DESKTOP 2>/dev/null
sudo rm /home/${SUDO_USER}/Desktop/$DESKTOP 2>/dev/null
sudo rm /usr/src/$SCRIPT 2>/dev/null
sudo rm /usr/src/$SCRIPT_WIN 2>/dev/null
sudo rm /home/${SUDO_USER}/name.txt /home/${SUDO_USER}/script.txt /home/${SUDO_USER}/diff.txt 2>/dev/null

echo "DVT ON/OFF Uninstalled"



