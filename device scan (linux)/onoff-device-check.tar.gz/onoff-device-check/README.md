### Set COM port, password, test time first
### Edit "dvt_reboot.sh"
COM=/dev/ttyTHS0
PW=nvidia
COUNT="10000"

### To install tool
### This will create a log folder with current time as its name
### PCIe/Storage golden file is in log folder as well
sudo ./install_dvt.sh

### To check error log
### check "diff" in log folder
### Error log includes:
    failed time
    error count
    difference from golden file
    device list when error was detected
    
### Remember to uninstall after test
sudo ./uninstall_dvt.sh
