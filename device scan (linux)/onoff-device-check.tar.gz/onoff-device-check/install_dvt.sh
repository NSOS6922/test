#!/bin/bash

### Check root permission
if [ "$EUID" -ne 0 ]; then
    echo "Please run with sudo"
    exit
fi


SCRIPT_WIN="dvt_win.sh"
SCRIPT="dvt_reboot.sh"
DESKTOP="dvt.desktop"
LOG=$(pwd)/log_$(date +%y-%m-%d_%H%M)
echo $LOG > name.txt

mkdir $LOG
mkdir $LOG/diff
echo 0 > $LOG/boot_count.log
echo 0 > $LOG/pcie_count.log
echo 0 > $LOG/blk_count.log
lspci > $LOG/PCIe_gloden.txt
lsblk > $LOG/Storage_gloden.txt

mkdir -p /home/${SUDO_USER}/.config/autostart/
cp $DESKTOP /home/${SUDO_USER}/.config/autostart/
sudo cp $SCRIPT /usr/src/
sudo cp $SCRIPT_WIN /usr/src/
sudo mv name.txt /home/${SUDO_USER}/



echo "DVT ON/OFF Installed (expected username/password = nvidia/nvidia)"
echo "> boot script: /usr/src/$SCRIPT"
echo "> will send 'I am good!' (no newline) to /dev/ttyTHS0 with baudrate 9600 after reboot"

