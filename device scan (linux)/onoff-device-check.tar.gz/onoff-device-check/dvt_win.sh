
### Add I am Good
gnome-terminal -- /usr/src/dvt_reboot.sh
